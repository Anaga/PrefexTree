import paho.mqtt.client as mqtt
import subprocess

#config
broker_name = "pi3lan"
topick_root = "forge/#"

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    #client.subscribe("$SYS/#")
    client.subscribe(topick_root)

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    topic_str = msg.topic
#    message_str = str(str(msg.payload),'utf-8')

    message_str = str(msg.payload,'utf-8')
    print("We got: "+topic_str+" : "+message_str)
    file.write(topic_str+" : "+message_str+'\n')
    if "WS" in topic_str:
       if "failed" in message_str:
          print("Failed,  solid")
          subprocess.run(["sudo","python","/home/pi/Forge/rpi_ws281x/setstatus.py","-t","10","-c","5","-s","f"])

       if "sucsess" in message_str:
          print("Sucsess, gren solid")
          subprocess.run(["sudo","python","/home/pi/Forge/rpi_ws281x/setstatus.py","-t","10","-c","5","-s","r"])

    if "BULB" in topic_str:
       print("Send comand to bulb:" + message_str)
       if "run" in message_str:
          print("Run, gren flicker")
          subprocess.run(["/home/pi/forge/bulb/playbulb.exp","55", "FF", "55", "1", "00"])
       if "sucsess" in message_str:
          print("Sucsess, gren solid")
          ssubprocess.run(["/home/pi/forge/bulb/playbulb.exp","55", "FF", "55", "0", "00"])
       if "failed" in message_str:
          print("failed, red solid")
          subprocess.run(["/home/pi/forge/bulb/playbulb.exp","FF", "55", "55", "1", "00"])
print("Create client")
client = mqtt.Client("Python poho client")
client.on_connect = on_connect
client.on_message = on_message
fileName="mqtt.log"
print("Save output to file %s"%fileName)
file=open(fileName,"a")
print("ready to connect");
client.connect(broker_name, 2883, 60)
print ("connected");
# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
print("ready to loop")
client.loop_forever()
print ("exit")
