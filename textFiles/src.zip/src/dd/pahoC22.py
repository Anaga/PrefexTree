import paho.mqtt.client as mqtt
import subprocess

#configure
broker_name = "PiZeroW"
topick_root = "forge/#"
ws_script   = "/home/pi/forge/ws281x/setstatus.py"

bulb_script = "/home/pi/forge/bulb/playbulb3.exp"
bulb_MAC = "4A:48:4B:19:AC:E6"

redSolidList  = ["00","FF","30","30","05","00"]
grenSolidList = ["00","30","FF","30","05","00"]
bluePulseList = ["00","30","30","FF","01","00"]

def ws_handle(inpStr):
    print("WS input str: "+inpStr)
    if ';' not in inpStr:
      print("Can't find delimeter in "+inpStr)
      return

    argList = inpStr.split(';')
    if len(argList)!= 3:
      print("WS expect only 3 args "+inpStr)
      return

    commandList = list()
    commandList.append("sudo")
    commandList.append("python")
    commandList.append(ws_script)
    commandList.append("-t")
    commandList.append(argList[0])
    commandList.append("-c")
    commandList.append(argList[1])
    commandList.append("-s")

    if "START" == argList[2]:
       commandList.append("r")
    if "SUCCESS" == argList[2]:
       commandList.append("p")
    if "FAILURE" == argList[2]:
       commandList.append("f")

    #print("Ready to send comand:")
    #print(commandList)
    subprocess.run(commandList)

    if argList[0]!=argList[1]: # this is not last segment
       #print("Not last segment")
       if "FAILURE" == argList[2]:
         # not update next segment if we failed
         print("No update if failed")
         return
       #print("command list:")
       #print(commandList)
       segment_number = int(argList[1])
       #print(segment_number)
       next_segment = segment_number+1
       #print(next_segment)
       str_next_segment = str(next_segment)
       #print("Aaaa")
       #print(commandList)
       commandList[6] = str_next_segment
       #print("BBB")
       #print(commandList)
       commandList[8] = "r"
       #print("ccCCC")
       #print(commandList)
       #print("Ready to send next comand:")
       #print(commandList)
       subprocess.run(commandList)


def bulb_handle(inpStr):
    print("BULB handle")
    #print("input str: "+inpStr)
    commandList = list()
    commandList.append(bulb_script) # [0] 
    commandList.append(bulb_MAC)    # [1]
    if "START" == inpStr:
        print("Started, blue pulse")
        commandList.extend(bluePulseList)

    if "SUCCESS" == inpStr:
        print("Sucsess, gren solid")
        commandList.extend(grenSolidList)

    if "FAILURE" == inpStr:
        print("Failed, red solid")
        commandList.extend(redSolidList)

    #print("Ready to send comand:")
    #print(commandList)
    subprocess.run(commandList)


# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    client.subscribe(topick_root)

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    topic_str = msg.topic
    message_str = str(msg.payload,'utf-8')
    print("We got: "+topic_str+" : "+message_str)
    file.write(topic_str+" : "+message_str+'\n')

    if "WS" in topic_str:
        #print("WS")
        ws_handle(message_str)

    if "BULB" in topic_str:
        #print("BULB")
        bulb_handle(message_str)


print("Create client")
client = mqtt.Client("Python poho client")
client.on_connect = on_connect
client.on_message = on_message
fileName="/tmp/mqtt.log"
print("Save output to file %s"%fileName)
file=open(fileName,"a")
print("ready to connect");
client.connect(broker_name, 2883, 60)
print ("connected");

print("ready to loop")
client.loop_forever()
print ("exit")


