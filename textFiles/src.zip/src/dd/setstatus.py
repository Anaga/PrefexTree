#!/usr/bin/env python3

import time
from neopixel import *
import argparse

# LED strip configuration:
LED_COUNT      = 96      # Number of LED pixels.
LED_PIN        = 18      # GPIO pin connected to the pixels (18 uses PWM!).
#LED_PIN        = 10      # GPIO pin connected to the pixels (10 uses SPI /dev/spidev0.0).
LED_FREQ_HZ    = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA        = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
LED_INVERT     = False   # True to invert the signal (when using NPN transistor level shift)
LED_CHANNEL    = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53
FAILED = Color(0,255,0)
RUNNING = Color(0,0,255)
PASSED = Color(255,0,0)
DIVIDER = Color(255,255,255)


def setStatus(strip, total, current, status):
    sectorLength =  strip.numPixels() / float(total)
    print sectorLength
    if status == 'r':
        NOW = RUNNING
    if status == 'f':
        NOW = FAILED
    if status == 'p':
        NOW = PASSED
    if current > 1:
        for i in range(0, int(sectorLength * (current - 1))):
            strip.setPixelColor(i, PASSED)
    for i in range(int(sectorLength * (current - 1)), int(sectorLength * current)):
        strip.setPixelColor(i, NOW)
    #set dividers
    for i in range(0, total):
        strip.setPixelColor(int(i * sectorLength), DIVIDER)
    strip.setPixelColor(LED_COUNT - 1, DIVIDER)
    strip.show()

if __name__ == '__main__':
    # Process arguments
    parser = argparse.ArgumentParser()
    #parser.add_argument('-c', '--clear', action='store_true', help='clear the display on exit')
    parser.add_argument('-t', '--total', help='total count of sectors')
    parser.add_argument('-c', '--current', help='current sector number')
    parser.add_argument('-s', '--status', help='current status - f, p, r')
    args = parser.parse_args()
    # Create NeoPixel object with appropriate configuration.
    strip = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    # Intialize the library (must be called once before other functions).
    strip.begin()

    setStatus(strip, int(args.total), int(args.current), args.status)
