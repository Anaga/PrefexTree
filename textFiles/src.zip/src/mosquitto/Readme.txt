Copy mosquitto.conf to /etc/mosquitto/conf.d/
